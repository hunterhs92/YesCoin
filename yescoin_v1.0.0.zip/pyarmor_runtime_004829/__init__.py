# Pyarmor 9.0.6 (basic), 004829, 2024-11-26T20:38:10.415555
from .pyarmor_runtime import __pyarmor__

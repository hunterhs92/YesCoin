# Pyarmor 9.0.6 (basic), 004829, 2024-11-26T19:29:24.720678
from .pyarmor_runtime import __pyarmor__
